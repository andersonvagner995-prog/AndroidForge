# WorkBot Android

Aplicação Android offline para gerir trabalhos e transações financeiras.

## Funcionalidades
- Criar, listar, editar, finalizar e excluir trabalhos.
- Ao finalizar um trabalho, cria automaticamente uma entrada financeira.
- Registar entradas, saídas e imprevistos.
- Resumo do mês atual.
- Dados guardados no armazenamento local do aplicativo (WebView localStorage).

## Compilação
Projeto Android Gradle. Pode ser enviado a um serviço de compilação Android compatível, como AndroidForge.
